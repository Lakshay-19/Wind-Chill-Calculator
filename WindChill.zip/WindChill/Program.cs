﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindChill
{
    class Program
    {
        static void Main(string[] args)
        {
            //Declaring variables & User inputs air temperature and air speed

            Console.WriteLine("Enter the air speed in Km/h");
            double AirSpeed = double.Parse(Console.ReadLine());
            Console.WriteLine("Enter the air temperature in celcius");
            double AirTemp = double.Parse(Console.ReadLine());

            //Wind chill calculation

            double WindChill = 13.12 + (0.6215 * AirTemp) - (11.37 * (Math.Pow(AirSpeed, 0.16))) + (0.3965 * AirTemp * (Math.Pow(AirSpeed, 0.16)));

            //Rounds answer to 1 decimal place

            WindChill = Math.Round(WindChill, 1);

            //Outputs answer

            Console.WriteLine("The wind chill is " + WindChill);

            Console.ReadKey();

        }
    }
}
